let mechanicId = 0;
let allVehicles = [];

window.onload = () => {
    document.getElementById("vehicle-menu").style.display = "none";
};

window.addEventListener("message", (event) => {
    if (event.data.action === "open") {
        mechanicId = event.data.mechanicId;
        allVehicles = event.data.vehicles;
        renderVehicleList(allVehicles);
        document.getElementById("vehicle-menu").style.display = "block";
    }
});

function renderVehicleList(vehicles) {
    const list = document.getElementById("vehicle-list");
    list.innerHTML = "";

    vehicles.forEach((veh, index) => {
        const div = document.createElement("div");
        div.classList.add("vehicle");
        div.innerHTML = `
            <h2>${veh.title}</h2>
            <p>${veh.description}</p>
            <p><strong>Make:</strong> ${veh.make}</p>
            <p><strong>Model:</strong> ${veh.model}</p>
            <p><strong>Plate:</strong> ${veh.plate}</p>
            <button onclick="spawnVehicle(${index})">Spawn</button>
        `;
        list.appendChild(div);
    });
}

function spawnVehicle(index) {
    fetch("https://eks_garage/spawnVehicle", {  // <-- Update to match actual resource name
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ index: index, mechanicId: mechanicId })
    })
    .then(response => {
        if (response.ok) {
            closeUI();
        } else {
            console.error("Vehicle spawn failed: Response not OK");
        }
    })
    .catch(err => {
        console.error("Spawn vehicle fetch error:", err);
    });
}

function closeUI() {
    document.getElementById("vehicle-menu").style.display = "none";
    fetch("https://EKS_Garage/close", { method: "POST" });
}

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
        closeUI();
    }
});

document.getElementById("search-input").addEventListener("input", function () {
    const filter = this.value.toLowerCase();
    const filtered = allVehicles.filter(veh =>
        veh.title.toLowerCase().includes(filter) ||
        veh.description.toLowerCase().includes(filter) ||
        veh.make.toLowerCase().includes(filter) ||
        veh.model.toLowerCase().includes(filter) ||
        veh.plate.toLowerCase().includes(filter)
    );
    renderVehicleList(filtered);
});
