local shownVehicles = {}

RegisterNetEvent('vehicleSpawner:openUI', function(mechanicId)
    local mechanic = Config.Mechanics[mechanicId]
    if not mechanic then return end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "open",
        vehicles = mechanic.vehicles,
        mechanicId = mechanicId
    })
end)

RegisterNUICallback('spawnVehicle', function(data, cb)
    local mechanic = Config.Mechanics[data.mechanicId]
    if not mechanic then return end
    local vehicleData = mechanic.vehicles[data.index]
    if not vehicleData then return end

    local foundSpot = nil
    for _, spot in ipairs(mechanic.parkingSpots) do
        if IsSpotClear(spot.coords) then
            foundSpot = spot
            break
        end
    end

    if not foundSpot then
        lib.notify({ title = "All Parking Spots Full", type = "error" })
        cb(false)
        return
    end

    RequestModel(vehicleData.spawncode)
    while not HasModelLoaded(vehicleData.spawncode) do Wait(0) end

    local veh = CreateVehicle(
        vehicleData.spawncode,
        foundSpot.coords.x,
        foundSpot.coords.y,
        foundSpot.coords.z + 0.5,
        foundSpot.heading,
        true, false
    )

    SetVehicleNumberPlateText(veh, vehicleData.plate)
    SetVehicleLivery(veh, vehicleData.livery or 0)
    SetEntityAsMissionEntity(veh, true, true)

    local blip = AddBlipForEntity(veh)
    SetBlipSprite(blip, 225)
    SetBlipColour(blip, 2)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Your Vehicle")
    EndTextCommandSetBlipName(blip)

    CreateThread(function()
        Wait(10000)
        RemoveBlip(blip)
    end)

    -- Honk 3 times after spawning
    CreateThread(function()
        for i = 1, 3 do
            StartVehicleHorn(veh, 500, GetHashKey("NORMAL"), false)
            Wait(700)
        end
    end)

    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })

    cb(true)
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb(true)
end)

function IsSpotClear(coords)
    local vehicles = GetGamePool("CVehicle")
    for _, veh in pairs(vehicles) do
        if #(GetEntityCoords(veh) - coords) < 2.5 then
            return false
        end
    end
    return true
end

CreateThread(function()
    Wait(1000)
    for i, mech in pairs(Config.Mechanics) do
        RequestModel(mech.pedModel)
        while not HasModelLoaded(mech.pedModel) do Wait(0) end

        local ped = CreatePed(0, mech.pedModel, mech.coords.x, mech.coords.y, mech.coords.z - 1.0, mech.heading, false, true)
        SetEntityAsMissionEntity(ped, true, true)
        SetEntityInvincible(ped, true)
        FreezeEntityPosition(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetPedCanRagdoll(ped, false)
        TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true)
        SetEntityCollision(ped, true, true)

        local blip = AddBlipForCoord(mech.coords)
        SetBlipSprite(blip, 402)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 5)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(mech.label or "Mechanic")
        EndTextCommandSetBlipName(blip)

        exports.ox_target:addBoxZone({
            coords = mech.coords,
            size = vec3(2, 2, 2),
            rotation = mech.heading,
            debug = false,
            options = {
                {
                    icon = "fa-solid fa-car",
                    label = "Request Vehicle",
                    onSelect = function()
                        TriggerEvent('vehicleSpawner:openUI', i)
                    end
                }
            }
        })
    end
end)