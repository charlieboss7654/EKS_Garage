local shownVehicles = {}

RegisterNetEvent('vehicleSpawner:openUI', function(mechanicId)
    local mechanic = Config.Mechanics[mechanicId]
    if not mechanic then return end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "open",
        vehicles = mechanic.vehicles,
        mechanicId = mechanicId
    })
end)

local function notify(title, description, type_)
    if lib and lib.notify then
        lib.notify({ title = title or 'Garage', description = description or '', type = type_ or 'inform' })
    else
        SetNotificationTextEntry("STRING")
        AddTextComponentString((title and (title .. "\n") or "") .. (description or ""))
        DrawNotification(false, true)
    end
end

RegisterNUICallback('spawnVehicle', function(data, cb)
    local mechanic = Config.Mechanics[data.mechanicId]
    if not mechanic then cb(false) return end

    local idx = tonumber(data.index) or 0
    idx = idx + 1

    local vehicleData = mechanic.vehicles[idx]
    if not vehicleData then
        notify('Garage', 'Invalid vehicle selection.', 'error')
        cb(false)
        return
    end

    local foundSpot
    for _, spot in ipairs(mechanic.parkingSpots) do
        if IsSpotClear(spot.coords) then
            foundSpot = spot
            break
        end
    end

    if not foundSpot then
        notify('Garage', 'All parking spots are full.', 'error')
        cb(false)
        return
    end

    local model = joaat(vehicleData.spawncode or '')
    if model == 0 or not IsModelInCdimage(model) or not IsModelAVehicle(model) then
        notify('Garage', ('Vehicle not found: %s'):format(tostring(vehicleData.spawncode)), 'error')
        cb(false)
        return
    end

    RequestModel(model)
    local waited = 0
    while not HasModelLoaded(model) do
        Wait(10)
        waited = waited + 10
        if waited > 5000 then
            notify('Garage', 'Model load timeout.', 'error')
            cb(false)
            return
        end
    end

    local x, y, z = foundSpot.coords.x, foundSpot.coords.y, foundSpot.coords.z + 0.5
    local veh = CreateVehicle(model, x, y, z, foundSpot.heading or 0.0, true, false)
    if veh == 0 then
        notify('Garage', 'Failed to create vehicle.', 'error')
        cb(false)
        return
    end

    SetEntityAsMissionEntity(veh, true, true)
    SetVehicleOnGroundProperly(veh)
    SetEntityHeading(veh, foundSpot.heading or 0.0)
    SetVehicleNumberPlateText(veh, vehicleData.plate or "EKS")
    if vehicleData.livery ~= nil then
        SetVehicleLivery(veh, vehicleData.livery)
    end

    local blip = AddBlipForEntity(veh)
    SetBlipSprite(blip, 225)
    SetBlipColour(blip, 2)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Your Vehicle")
    EndTextCommandSetBlipName(blip)
    CreateThread(function()
        Wait(10000)
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end)

    CreateThread(function()
        for i = 1, 3 do
            StartVehicleHorn(veh, 500, GetHashKey("NORMAL"), false)
            Wait(700)
        end
    end)

    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })

    cb(true)
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb(true)
end)

function IsSpotClear(coords)
    local vehicles = GetGamePool("CVehicle")
    for _, veh in pairs(vehicles) do
        if #(GetEntityCoords(veh) - coords) < 2.5 then
            return false
        end
    end
    return true
end

CreateThread(function()
    Wait(1000)
    for i, mech in pairs(Config.Mechanics) do
        RequestModel(mech.pedModel)
        while not HasModelLoaded(mech.pedModel) do Wait(0) end

        local ped = CreatePed(0, mech.pedModel, mech.coords.x, mech.coords.y, mech.coords.z - 1.0, mech.heading, false, true)
        SetEntityAsMissionEntity(ped, true, true)
        SetEntityInvincible(ped, true)
        FreezeEntityPosition(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetPedCanRagdoll(ped, false)
        TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true)
        SetEntityCollision(ped, true, true)

        local blip = AddBlipForCoord(mech.coords)
        SetBlipSprite(blip, 402)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 5)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(mech.label or "Mechanic")
        EndTextCommandSetBlipName(blip)

        exports.ox_target:addBoxZone({
            coords = mech.coords,
            size = vec3(2, 2, 2),
            rotation = mech.heading,
            debug = false,
            options = {
                {
                    icon = "fa-solid fa-car",
                    label = "Request Vehicle",
                    onSelect = function()
                        TriggerEvent('vehicleSpawner:openUI', i)
                    end
                }
            }
        })
    end
end)
