fx_version 'cerulean'
game 'gta5'
author 'R.Robertson - Echo Kilo Studios'

lua54 'yes'
shared_script '@ox_lib/init.lua'


shared_script 'shared/config.lua'
client_script 'client/client.lua'
server_script 'server/server.lua'

ui_page 'html/ui.html'

files {
  'html/ui.html',
  'html/style.css',
  'html/script.js'
}
