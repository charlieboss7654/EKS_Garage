Config = {}

Config.Mechanics = {
    {
        label = "Police Depot",
        coords = vector3(429.33, -1028.66, 28.96),
        heading = 158.54,
        pedModel = "s_m_y_xmech_02",
        parkingSpots = {
            { coords = vector3(436.7, -1023.88, 28.75), heading = 108.0 },
            { coords = vector3(426.96, -1018.95, 28.98), heading = 108.0 }
        },

        vehicles = {
            {
                title = "Marked Patrol Car",
                description = "Standard patrol vehicle for routine duties.",
                make = "Vapid",
                model = "police3",
                plate = "PD01",
                livery = 1,
                spawncode = "police3"
            },
            {
                title = "Unmarked Unit",
                description = "Covert surveillance SUV.",
                make = "Declasse",
                model = "granger",
                plate = "UCV02",
                livery = 0,
                spawncode = "granger"
            },
            {
                title = "Unmarked Unit",
                description = "Covert surveillance SUV.",
                make = "Declasse",
                model = "granger",
                plate = "UCV02",
                livery = 0,
                spawncode = "granger"
            }

        }
    }
}
