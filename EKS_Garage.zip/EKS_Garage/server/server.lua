RegisterCommand("openvehui", function(source)
    TriggerClientEvent('vehicleSpawner:openUI', source, 1) 
end)
