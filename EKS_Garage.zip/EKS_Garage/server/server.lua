RegisterCommand("openvehui", function(source)
    TriggerClientEvent('vehicleSpawner:openUI', source, 1) -- example: mechanic 1
end)
